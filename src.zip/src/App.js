import React, { Component } from 'react';
import PropTypes from 'prop-types';
import styles from './App.module.css';
import Grid from '@material-ui/core/Grid';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import NavBar from './components/NavBar';
import Form from './components/Form';
//import Table from './components/Table';

class App extends Component {

render() {

  console.log('HTML rendered!');
  return (
    <div className={styles.app}>
          <NavBar />
      <div className={styles.content}>
        <Grid container spacing={36}>
          <Grid item xs={16} sm={24}>
            <Card>
              <CardContent>
                number and data. use the material-ui and three components. use the
                react-table but it only show the last row in the table.
              </CardContent>
            </Card>
          <Form />
          </Grid>
          </Grid>
          </div>
          </div>
  );
}
}
App.propTypes = {
  // Define a list of props and typecast them
  locale: PropTypes.string,
};

export default App;
