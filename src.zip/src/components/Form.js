import React from 'react'
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import Button from '@material-ui/core/Button';
import KeyboardArrowUp from '@material-ui/icons/KeyboardArrowUp';
import KeyboardArrowDown from '@material-ui/icons/KeyboardArrowDown';
import TextField from '@material-ui/core/TextField';
import Fab from '@material-ui/core/Fab';
import SimpleTable from '../components/Table.js';

class Form extends React.Component {
constructor(props) {
  super(props);
  this.state ={
    liveData: {
       count: 0,
        value: '',
    },
    savedData: {
       count:'',
        value: '',
    }
  }
  this.handleClickup = this.handleClickup.bind(this);
  this.handleClickdown = this.handleClickdown.bind(this);
  this.handleChange = this.handleChange.bind(this);
  this.handleSubmit = this.handleSubmit.bind(this);
}

handleClickup() {
  this.setState((state) =>{
    return{
      liveData: {
      count: this.state.liveData.count+1
    }
  }
  });
}
handleClickdown() {
if(this.state.liveData.count>=1)
{
this.setState((state) => {
  return{
    liveData: {
    count: this.state.liveData.count-1
  }
}
});
}
}
handleChange(e) {
this.setState({
  liveData: {
      count: e.target.id,
      value: e.target.value,
  }
});
}

handleSubmit(event) {
alert('data was submitted');
event.preventDefault();
const { liveData } = this.state;
this.setState({
    savedData: liveData,
});
}
render() {
  console.log('HTML rendered!');
  const { liveData, savedData } = this.state;
  return (
    <Card>
    <CardContent>
        <form onSubmit={this.handleSubmit}>
    <Fab
    variant="extended"
    size="small"
    color="primary"
    aria-label="up"
    onClick={this.handleClickup}
  >
    <KeyboardArrowUp />
    +
  </Fab>
  <Card>
    <CardContent>
    <h1>{liveData.count}</h1>
    </CardContent>
  </Card>

  <Fab
  variant="extended"
  size="small"
  color="primary"
  aria-label="down"
  onClick={this.handleClickdown}
>
  <KeyboardArrowDown />
  -
</Fab>
<Card>
        <TextField
        id={liveData.count}
        name="value"
        value={liveData.value}
        onChange={this.handleChange}
        />
        <Button
          variant="contained"
          color="secondary"
          type="submit"
          Value="Add"
        >
      Primary
        </Button>
        </Card>
        </form>
        </CardContent>
          <SimpleTable Data={savedData}/>
        </Card>

    );
  }
}

export default Form;
