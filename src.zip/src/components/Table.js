import React from 'react';
// Import React Table
import ReactTable from "react-table";
import "react-table/react-table.css";

class SimpleTable extends  React.Component {
  render() {
    const data = [{
      number: this.props.Data.count,
      value: this.props.Data.value
    }]
    const columns = [{
      Header: 'Number',
      accessor: 'number'
    },
    {
      Header: 'Value',
      accessor: 'value'
    }]

   return (
      <div>
      <ReactTable
      data={data}
      columns={columns}
      defaultPageSize = {3}
      pageSizeOptions = {[3, 6]}
      />
      </div>
  );
}
}
export default SimpleTable;
